using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public static GameObject player;
    public static GameObject currentPlatform;
    Rigidbody rb;

    private void OnCollisionEnter(Collision collision)
    {
        currentPlatform = collision.gameObject;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other is BoxCollider && PlatformSpawner.lastPlatform.tag != "platformT")
        {
            PlatformSpawner.RunDummy();
        }
    }
    private void Start()
    {
        player = this.gameObject;
        rb = GetComponent<Rigidbody>();
        PlatformSpawner.RunDummy();
    }
}
