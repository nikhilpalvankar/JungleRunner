using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public static GameObject player;
    public static GameObject currentPlatform;
    Rigidbody rb;

    private void OnCollisionEnter(Collision collision)
    {
        currentPlatform = collision.gameObject;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other is BoxCollider && PlatformSpawner.lastPlatform.tag!="platformT")
        {
            PlatformSpawner.RunDummy();
        }
    }
    private void Start()
    {
        rb = this.GetComponent<Rigidbody>();
        player = this.gameObject;
        PlatformSpawner.RunDummy();
    }
}
